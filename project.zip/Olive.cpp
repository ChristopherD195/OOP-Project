#include "Olive.h"
#include <iostream>

Olive::Olive() : FruitOrVeg("olive") {}

void Olive::renderTopping(){
    std::cout<<"Olive rendered successfully"<<std::endl;
};