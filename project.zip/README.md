# OOP-Project

Pizzeria Game
When you open the game for the first time/dont have a save file, you will be prompted to begin the game by pressing enter.

The game will give you step by step instructions what is happening within the game, and what inputs are required inorder to make the pizza. Below will be instructions to help if you get stuck.

Toppings:
    The Customer displayed the type and quantity of toppings they want for their pizza, and your job is to recreate their order.

    The sequence of actions for adding toppings to the pizza are as follows. If you want to quit, enter "q" and your data and customer pizza order will be saved:
        1. Pick which topping you want to add (inputs: 1,2,3,4)
        2. Do you want to add another topping
    This will loop for as along as you want to keep adding toppings

Baking:
    Entering 1 when prompted to bake the pizza will take a timer for how long the pizza has been in the oven.
        Entering 1 once prompted to take the pizza out of the oven will record how long the pizza has been baking for (which you have to estimate)

Cutting:
    You will be prompted to enter how many cuts you want to make on the pizza, which should match how many the Customer ordered. 
        Once a number is entered, that will determine how many cuts the pizza has

After these 3 process, the Customer will evaluate your pizza you made in accordance to what the Customer wanted. Efficiency scores out of 1 will be displayed for each process (topping, baking and cutting) and the Customer will give you feedback on how well you did.

Finally, you will recieve a tip which is based on how well you made the pizza according to what the Customer ordered.

Throughout the game, you were prompted if you wanted to quit the game and your process will be saved. If you save, it will allow you to continue making the pizza you currently were making and also your cumulative tips by playing the game.


